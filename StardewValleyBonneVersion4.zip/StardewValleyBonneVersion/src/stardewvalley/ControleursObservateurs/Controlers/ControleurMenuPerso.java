/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stardewvalley.ControleursObservateurs.Controlers;

import stardewvalley.Metier.Partie;

/**
 *
 * @author ea058452
 */
public class ControleurMenuPerso extends Controler {
    
    @Override
    public void warn() {
        this.update();
    }
    
}
