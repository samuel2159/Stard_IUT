/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stardewvalley.Vues.Inventaire;

import stardewvalley.Metier.Personnages.Inventaire.Inventaire;

/**
 *
 * @author telli
 */
public class VueFavoris {
    
    Inventaire inventaire;
    
    public VueFavoris(Inventaire i){
        inventaire = i;
    }
    
    
    
}
