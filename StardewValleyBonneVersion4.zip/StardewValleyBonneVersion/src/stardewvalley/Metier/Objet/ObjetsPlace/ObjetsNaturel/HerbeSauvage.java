/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stardewvalley.Metier.Objet.ObjetsPlace.ObjetsNaturel;

/**
 * Herbe sauvage du jeu
 * @author Kevin Lamblin
 */
public class HerbeSauvage extends ObjetNaturel{

    @Override
    /**
     * @author Kevin Lamblin
     */
    public void Interagir() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    /**
     * @author Kevin Lamblin
     * @return String
     */
    public String getType() {
       return "herbe";
    }
    
}
