/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stardewvalley.Metier.Personnages;

/**
 *
 * @author simonetma
 */
public class NPC extends Personnage {
    
    public NPC(NomPersonnage nom) {
        super(nom);
    }
    
}
