/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stardewvalley.Metier.Personnages.Inventaire;

import java.util.ArrayList;
import stardewvalley.Metier.Personnages.Inventaire.Objets.Objet;

/**
 *
 * @author telli
 */
public class Inventaire {
    
    public ArrayList<Objet> getObjets(){
        return new ArrayList<>();
    }
    
}
